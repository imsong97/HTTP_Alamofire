//
//  ViewController.swift
//  HTTPconnect
//
//  Created by SONG YUN-HO on 2020/12/08.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var userId:UITextField!
    @IBOutlet weak var otp:UITextField!
    @IBOutlet weak var result:UITextView!
    
    let get_url:String = "http://www.google.co.kr"
    let post_url:String = "link"

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func post(_ sender: UIButton){
        let json:[String: String] = ["userId":userId.text!, "otp":otp.text!]
        let response = AF.request(post_url, method: .post, parameters: json, encoding: JSONEncoding.default, headers: ["Content-Type":"application/json", "Accept":"application/json"])
        response.responseString{ res in
            switch res.result{
            case .success(let value):
                self.result.text = "POST SUCCESS\n" + value
            case .failure(let value):
                self.result.text = "POST FAIL"
                print(value)
            }
        }
    }
    
    @IBAction func get(_ sender: UIButton){
        let response = AF.request(get_url)
        response.responseString{ res in
            switch res.result{
            case .success(let value):
                self.result.text = "GET SUCCESS\n" + value
            case .failure(let value):
                self.result.text = "GET FAIL"
                print(value)
            }
        }
    }
}
